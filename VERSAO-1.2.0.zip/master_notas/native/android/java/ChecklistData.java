package com.rodrigo.master_notas;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;

/** Leitura e escrita do arquivo de notas (o mesmo que o app Flutter usa). */
final class ChecklistData {
    private static final String PREFS = "checklist_widget";

    private ChecklistData() {
    }

    static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    static void setDataPath(Context c, String path) {
        if (path != null && path.length() > 0) {
            prefs(c).edit().putString("data_path", path).apply();
        }
    }

    static File dataFile(Context c) {
        String p = prefs(c).getString("data_path", null);
        if (p != null) {
            File f = new File(p);
            if (f.exists()) {
                return f;
            }
        }
        return new File(c.getDir("flutter", Context.MODE_PRIVATE), "master_notas.json");
    }

    static JSONObject read(Context c) {
        try {
            File f = dataFile(c);
            if (!f.exists()) {
                return null;
            }
            InputStream in = new FileInputStream(f);
            try {
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                byte[] buf = new byte[8192];
                int n;
                while ((n = in.read(buf)) > 0) {
                    out.write(buf, 0, n);
                }
                return new JSONObject(new String(out.toByteArray(), "UTF-8"));
            } finally {
                in.close();
            }
        } catch (Exception e) {
            return null;
        }
    }

    static boolean write(Context c, JSONObject root) {
        try {
            File f = dataFile(c);
            File tmp = new File(f.getPath() + ".tmp");
            FileOutputStream out = new FileOutputStream(tmp);
            try {
                out.write(root.toString().getBytes("UTF-8"));
                out.getFD().sync();
            } finally {
                out.close();
            }
            return tmp.renameTo(f);
        } catch (Exception e) {
            return false;
        }
    }

    static String widgetNoteId(Context c, int widgetId) {
        return prefs(c).getString("note_" + widgetId, null);
    }

    static void setWidgetNoteId(Context c, int widgetId, String noteId) {
        prefs(c).edit().putString("note_" + widgetId, noteId).apply();
    }

    static void clearWidget(Context c, int widgetId) {
        prefs(c).edit().remove("note_" + widgetId).apply();
    }

    static JSONObject findNote(JSONObject root, String id) {
        if (root == null || id == null) {
            return null;
        }
        JSONArray notes = root.optJSONArray("notes");
        if (notes == null) {
            return null;
        }
        for (int i = 0; i < notes.length(); i++) {
            JSONObject n = notes.optJSONObject(i);
            if (n != null && id.equals(n.optString("id"))) {
                return n;
            }
        }
        return null;
    }

    static boolean isTrashed(JSONObject note) {
        return note.has("deleted") && !note.isNull("deleted");
    }

    /** Inverte o item marcado/desmarcado e grava no arquivo. */
    static boolean toggle(Context c, String noteId, String blockId) {
        try {
            JSONObject root = read(c);
            JSONObject note = findNote(root, noteId);
            if (note == null) {
                return false;
            }
            JSONArray blocks = note.optJSONArray("blocks");
            if (blocks == null) {
                return false;
            }
            for (int i = 0; i < blocks.length(); i++) {
                JSONObject b = blocks.optJSONObject(i);
                if (b == null) {
                    continue;
                }
                if ("check".equals(b.optString("t")) && blockId.equals(b.optString("id"))) {
                    b.put("k", !b.optBoolean("k", false));
                    note.put("updated", System.currentTimeMillis());
                    return write(c, root);
                }
            }
        } catch (Exception e) {
            // ignora
        }
        return false;
    }
}
