package com.rodrigo.master_notas;

import android.app.Activity;
import android.appwidget.AppWidgetManager;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/** Tela que abre ao adicionar o widget: escolher qual lista ele vai mostrar. */
public class ChecklistConfigActivity extends Activity {
    private int widgetId = AppWidgetManager.INVALID_APPWIDGET_ID;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setResult(RESULT_CANCELED);

        Intent intent = getIntent();
        if (intent != null && intent.getExtras() != null) {
            widgetId = intent.getExtras().getInt(
                    AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID);
        }
        if (widgetId == AppWidgetManager.INVALID_APPWIDGET_ID) {
            finish();
            return;
        }

        JSONObject root = ChecklistData.read(this);
        List<JSONObject> notes = new ArrayList<JSONObject>();
        if (root != null) {
            JSONArray all = root.optJSONArray("notes");
            if (all != null) {
                for (int i = 0; i < all.length(); i++) {
                    JSONObject n = all.optJSONObject(i);
                    if (n == null || ChecklistData.isTrashed(n)) {
                        continue;
                    }
                    if (countItems(n, false) > 0) {
                        notes.add(n);
                    }
                }
            }
        }

        if (notes.isEmpty()) {
            Toast.makeText(this,
                    "Crie primeiro uma nota com lista de tarefas no app.",
                    Toast.LENGTH_LONG).show();
            finish();
            return;
        }

        Collections.sort(notes, new Comparator<JSONObject>() {
            @Override
            public int compare(JSONObject a, JSONObject b) {
                return Long.compare(b.optLong("updated"), a.optLong("updated"));
            }
        });

        final List<String> ids = new ArrayList<String>();
        List<String> labels = new ArrayList<String>();
        for (JSONObject n : notes) {
            ids.add(n.optString("id"));
            labels.add(labelFor(n));
        }

        ListView list = new ListView(this);
        list.setAdapter(new ArrayAdapter<String>(
                this, android.R.layout.simple_list_item_1, labels));
        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                ChecklistData.setWidgetNoteId(ChecklistConfigActivity.this, widgetId, ids.get(position));
                AppWidgetManager manager = AppWidgetManager.getInstance(ChecklistConfigActivity.this);
                ChecklistWidgetProvider.update(ChecklistConfigActivity.this, manager, widgetId);

                Intent result = new Intent();
                result.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId);
                setResult(RESULT_OK, result);
                finish();
            }
        });

        setTitle("Escolha a lista");
        setContentView(list);
    }

    private static int countItems(JSONObject note, boolean onlyDone) {
        JSONArray blocks = note.optJSONArray("blocks");
        if (blocks == null) {
            return 0;
        }
        int count = 0;
        for (int i = 0; i < blocks.length(); i++) {
            JSONObject b = blocks.optJSONObject(i);
            if (b == null || !"check".equals(b.optString("t"))) {
                continue;
            }
            if (b.optString("x", "").trim().length() == 0) {
                continue;
            }
            if (!onlyDone || b.optBoolean("k", false)) {
                count++;
            }
        }
        return count;
    }

    private static String labelFor(JSONObject note) {
        String title = note.optString("title", "").trim();
        if (title.length() == 0) {
            JSONArray blocks = note.optJSONArray("blocks");
            if (blocks != null) {
                for (int i = 0; i < blocks.length(); i++) {
                    JSONObject b = blocks.optJSONObject(i);
                    if (b != null && "check".equals(b.optString("t"))
                            && b.optString("x", "").trim().length() > 0) {
                        title = b.optString("x", "").trim();
                        break;
                    }
                }
            }
        }
        if (title.length() == 0) {
            title = "Sem titulo";
        }
        return title + "  (" + countItems(note, true) + "/" + countItems(note, false) + ")";
    }
}
