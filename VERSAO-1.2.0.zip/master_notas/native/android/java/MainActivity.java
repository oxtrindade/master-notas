package com.rodrigo.master_notas;

import io.flutter.embedding.android.FlutterActivity;
import io.flutter.embedding.engine.FlutterEngine;
import io.flutter.plugin.common.MethodCall;
import io.flutter.plugin.common.MethodChannel;

/** Troca a MainActivity padrão para receber o aviso "atualize o widget" do app. */
public class MainActivity extends FlutterActivity {
    private static final String CHANNEL = "master_notas/widget";

    @Override
    public void configureFlutterEngine(FlutterEngine flutterEngine) {
        super.configureFlutterEngine(flutterEngine);
        new MethodChannel(flutterEngine.getDartExecutor().getBinaryMessenger(), CHANNEL)
                .setMethodCallHandler(new MethodChannel.MethodCallHandler() {
                    @Override
                    public void onMethodCall(MethodCall call, MethodChannel.Result result) {
                        if ("refresh".equals(call.method)) {
                            String path = call.argument("path");
                            ChecklistData.setDataPath(getApplicationContext(), path);
                            ChecklistWidgetProvider.refreshAll(getApplicationContext());
                            result.success(null);
                        } else {
                            result.notImplemented();
                        }
                    }
                });
    }
}
