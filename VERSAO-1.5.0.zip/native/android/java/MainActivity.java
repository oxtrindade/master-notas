package com.rodrigo.master_notas;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;

import java.util.HashMap;
import java.util.Map;

import io.flutter.embedding.android.FlutterActivity;
import io.flutter.embedding.engine.FlutterEngine;
import io.flutter.plugin.common.BinaryMessenger;
import io.flutter.plugin.common.MethodCall;
import io.flutter.plugin.common.MethodChannel;

/**
 * Troca a MainActivity padrao para receber pedidos do app:
 *  - master_notas/widget: atualizar o widget da tela inicial
 *  - master_notas/files: escolher uma pasta e gravar/ler o backup nela
 */
public class MainActivity extends FlutterActivity {
    private static final String WIDGET_CHANNEL = "master_notas/widget";
    private static final String FILES_CHANNEL = "master_notas/files";
    private static final int REQ_PICK_FOLDER = 4711;

    private MethodChannel.Result pendingPick;

    private interface Job {
        Object run() throws Exception;
    }

    @Override
    public void configureFlutterEngine(FlutterEngine flutterEngine) {
        super.configureFlutterEngine(flutterEngine);
        BinaryMessenger messenger = flutterEngine.getDartExecutor().getBinaryMessenger();

        new MethodChannel(messenger, WIDGET_CHANNEL)
                .setMethodCallHandler(new MethodChannel.MethodCallHandler() {
                    @Override
                    public void onMethodCall(MethodCall call, MethodChannel.Result result) {
                        if ("refresh".equals(call.method)) {
                            String path = call.argument("path");
                            ChecklistData.setDataPath(getApplicationContext(), path);
                            ChecklistWidgetProvider.refreshAll(getApplicationContext());
                            result.success(null);
                        } else {
                            result.notImplemented();
                        }
                    }
                });

        new MethodChannel(messenger, FILES_CHANNEL)
                .setMethodCallHandler(new MethodChannel.MethodCallHandler() {
                    @Override
                    public void onMethodCall(MethodCall call, MethodChannel.Result result) {
                        handleFiles(call, result);
                    }
                });
    }

    private void handleFiles(MethodCall call, MethodChannel.Result result) {
        final Context context = getApplicationContext();
        final String method = call.method;

        if ("pickFolder".equals(method)) {
            if (pendingPick != null) {
                result.error("busy", "Escolha de pasta já em andamento.", null);
                return;
            }
            pendingPick = result;
            Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION
                    | Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                    | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
                    | Intent.FLAG_GRANT_PREFIX_URI_PERMISSION);
            startActivityForResult(intent, REQ_PICK_FOLDER);
            return;
        }

        final String uriText = call.argument("uri");
        final String name = call.argument("name");
        final String text = call.argument("text");
        if (uriText == null) {
            result.error("bad_args", "Pasta não informada.", null);
            return;
        }
        final Uri tree = Uri.parse(uriText);

        if ("saveToFolder".equals(method)) {
            runAsync(new Job() {
                @Override
                public Object run() throws Exception {
                    FolderAccess.write(context, tree, name, text == null ? "" : text);
                    return Boolean.TRUE;
                }
            }, result);
        } else if ("readFromFolder".equals(method)) {
            runAsync(new Job() {
                @Override
                public Object run() throws Exception {
                    return FolderAccess.read(context, tree, name);
                }
            }, result);
        } else if ("checkFolder".equals(method)) {
            result.success(FolderAccess.hasPermission(context, tree));
        } else if ("releaseFolder".equals(method)) {
            FolderAccess.release(context, tree);
            result.success(null);
        } else {
            result.notImplemented();
        }
    }

    /** Roda o trabalho fora da tela e devolve o resultado na thread principal. */
    private void runAsync(final Job job, final MethodChannel.Result result) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                Object value = null;
                String error = null;
                try {
                    value = job.run();
                } catch (Exception e) {
                    error = String.valueOf(e.getMessage());
                }
                final Object fValue = value;
                final String fError = error;
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (fError != null) {
                            result.error("folder_failed", fError, null);
                        } else {
                            result.success(fValue);
                        }
                    }
                });
            }
        }).start();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQ_PICK_FOLDER) {
            return;
        }
        MethodChannel.Result r = pendingPick;
        pendingPick = null;
        if (r == null) {
            return;
        }
        if (resultCode != RESULT_OK || data == null || data.getData() == null) {
            r.success(null); // cancelou
            return;
        }
        Uri uri = data.getData();
        try {
            getContentResolver().takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            Map<String, String> map = new HashMap<String, String>();
            map.put("uri", uri.toString());
            map.put("name", FolderAccess.displayName(getApplicationContext(), uri));
            r.success(map);
        } catch (Exception e) {
            r.error("perm_failed",
                    "O Android não permitiu guardar o acesso a esta pasta: " + e.getMessage(),
                    null);
        }
    }
}
